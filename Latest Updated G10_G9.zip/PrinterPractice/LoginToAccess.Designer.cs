﻿namespace PrinterPractice
{
    partial class LoginToAccess
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginToAccess));
            label1 = new Label();
            txtUsername = new TextBox();
            label2 = new Label();
            label3 = new Label();
            txtPass = new TextBox();
            btnLogin = new Button();
            backGradiant1 = new BackGradiant();
            backGradiant1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Bahnschrift", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(192, 0, 0);
            label1.Location = new Point(168, 7);
            label1.Name = "label1";
            label1.Size = new Size(147, 29);
            label1.TabIndex = 0;
            label1.Text = "Admin Login";
            // 
            // txtUsername
            // 
            txtUsername.Font = new Font("Bahnschrift", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUsername.Location = new Point(168, 54);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(157, 27);
            txtUsername.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Bahnschrift", 12F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(78, 57);
            label2.Name = "label2";
            label2.Size = new Size(84, 19);
            label2.TabIndex = 0;
            label2.Text = "Username";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Bahnschrift", 12F);
            label3.ForeColor = Color.White;
            label3.Location = new Point(78, 102);
            label3.Name = "label3";
            label3.Size = new Size(81, 19);
            label3.TabIndex = 0;
            label3.Text = "Password";
            // 
            // txtPass
            // 
            txtPass.Font = new Font("Bahnschrift", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPass.Location = new Point(168, 99);
            txtPass.Name = "txtPass";
            txtPass.Size = new Size(157, 27);
            txtPass.TabIndex = 1;
            txtPass.UseSystemPasswordChar = true;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.White;
            btnLogin.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogin.ForeColor = Color.MidnightBlue;
            btnLogin.Location = new Point(168, 150);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(124, 37);
            btnLogin.TabIndex = 2;
            btnLogin.Text = "Login";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            btnLogin.MouseClick += btnLogin_MouseClick;
            // 
            // backGradiant1
            // 
            backGradiant1.ColorBottom = Color.LightCyan;
            backGradiant1.ColorTop = Color.DarkTurquoise;
            backGradiant1.Controls.Add(label1);
            backGradiant1.Controls.Add(btnLogin);
            backGradiant1.Controls.Add(label2);
            backGradiant1.Controls.Add(txtPass);
            backGradiant1.Controls.Add(txtUsername);
            backGradiant1.Controls.Add(label3);
            backGradiant1.Location = new Point(1, 1);
            backGradiant1.Name = "backGradiant1";
            backGradiant1.Size = new Size(458, 203);
            backGradiant1.TabIndex = 3;
            // 
            // LoginToAccess
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.AliceBlue;
            ClientSize = new Size(459, 201);
            Controls.Add(backGradiant1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "LoginToAccess";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin Login";
            Load += LoginToAccess_Load;
            backGradiant1.ResumeLayout(false);
            backGradiant1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private TextBox txtUsername;
        private Label label2;
        private Label label3;
        private TextBox txtPass;
        private Button btnLogin;
        private BackGradiant backGradiant1;
    }
}