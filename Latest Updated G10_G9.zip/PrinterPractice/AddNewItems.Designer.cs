﻿namespace PrinterPractice
{
    partial class AddNewItems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewItems));
            txtNewItemAdd = new TextBox();
            label1 = new Label();
            btnAdd = new Button();
            backGradiant1 = new BackGradiant();
            backGradiant1.SuspendLayout();
            SuspendLayout();
            // 
            // txtNewItemAdd
            // 
            txtNewItemAdd.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNewItemAdd.Location = new Point(83, 43);
            txtNewItemAdd.Name = "txtNewItemAdd";
            txtNewItemAdd.Size = new Size(241, 29);
            txtNewItemAdd.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(192, 0, 0);
            label1.Location = new Point(96, 10);
            label1.Name = "label1";
            label1.Size = new Size(207, 21);
            label1.TabIndex = 1;
            label1.Text = "Add New Item Name here";
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.White;
            btnAdd.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.ForeColor = Color.MidnightBlue;
            btnAdd.Location = new Point(145, 84);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(109, 37);
            btnAdd.TabIndex = 2;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // backGradiant1
            // 
            backGradiant1.ColorBottom = Color.LightCyan;
            backGradiant1.ColorTop = Color.DarkTurquoise;
            backGradiant1.Controls.Add(txtNewItemAdd);
            backGradiant1.Controls.Add(btnAdd);
            backGradiant1.Controls.Add(label1);
            backGradiant1.Location = new Point(1, 0);
            backGradiant1.Name = "backGradiant1";
            backGradiant1.Size = new Size(424, 134);
            backGradiant1.TabIndex = 3;
            // 
            // AddNewItems
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.AliceBlue;
            ClientSize = new Size(423, 132);
            Controls.Add(backGradiant1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "AddNewItems";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Add New Items";
            Load += AddNewItems_Load;
            backGradiant1.ResumeLayout(false);
            backGradiant1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TextBox txtNewItemAdd;
        private Label label1;
        private Button btnAdd;
        private BackGradiant backGradiant1;
    }
}