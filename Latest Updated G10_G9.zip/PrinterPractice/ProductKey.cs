﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrinterPractice
{
    public partial class ProductKey : Form
    {
        public ProductKey()
        {
            InitializeComponent();
        }

        private void btnActivate_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            foreach (Control c in this.Controls)
            {
                if (c is TextBox)
                {
                    sb.Append(c.Text);
                }
            }
            activation.activateSoftware(sb.ToString());
            // Check if activation was successful, then close this form and open the main form
            if (activation.IsActivated)
            {
                MessageBox.Show("Activation successful. The application will now restart.");
                Application.Restart();
            }
        }
    }
}
