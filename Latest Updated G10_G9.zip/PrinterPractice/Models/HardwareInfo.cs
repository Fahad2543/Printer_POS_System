﻿using System;
using System.Management;

public static class HardwareInfo
{
    public static string GetHardwareID()
    {
        string cpuId = string.Empty;
        ManagementClass mc = new ManagementClass("win64_processor");
        ManagementObjectCollection moc = mc.GetInstances();

        foreach (ManagementObject mo in moc)
        {
            cpuId = mo.Properties["processorID"].Value.ToString();
            break;
        }

        return cpuId;
    }
}
