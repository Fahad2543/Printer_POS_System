﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrinterPractice.Models
{
    public class CartItem
    {
        public string ItemName { get; set; }
        public decimal Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Total_Price { get; set; }
        public decimal? After_Disc { get; set; }
        public decimal After_Disc_Total { get; set; }
    }
}
