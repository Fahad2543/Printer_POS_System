﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrinterPractice
{
    public partial class LoginToNewSalesman : Form
    {
        public LoginToNewSalesman()
        {
            InitializeComponent();
        }

        private void btnLoginSaleMan_MouseClick(object sender, MouseEventArgs e)
        {
            String username = "Admin";
            String password = "123";

            string inputUsername = txtUsernameSales.Text;
            string inputPassword = txtPassSales.Text;

            if (txtUsernameSales.Text == "" || txtPassSales.Text == "")
            {
                MessageBox.Show("Please fill the empty box");
            }
            else
            {
                if (inputUsername == username && inputPassword == password)
                {

                    AddNewSaleManItem addNewItems = new AddNewSaleManItem();
                    addNewItems.Show();
                    this.Hide();
                }
                else
                {

                    MessageBox.Show("Please Correct username or password");
                    txtUsernameSales.Clear();
                    txtPassSales.Clear();

                }
            }
        }

        private void btnLoginSaleMan_Click(object sender, EventArgs e)
        {

        }
    }
}
