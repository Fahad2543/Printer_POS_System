﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrinterPractice
{
    public partial class LoginToAccess : Form
    {
        public LoginToAccess()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            
        }

        private void LoginToAccess_Load(object sender, EventArgs e)
        {
            txtUsername.Focus();
        }

        private void btnLogin_MouseClick(object sender, MouseEventArgs e)
        {
            String username = "Admin";
            String password = "123";

            string inputUsername = txtUsername.Text;
            string inputPassword = txtPass.Text;

            if (txtUsername.Text == "" || txtPass.Text == "")
            {
                MessageBox.Show("Please fill the empty box");
            }
            else
            {
                if (inputUsername == username && inputPassword == password)
                {

                    AddNewItems addNewItems = new AddNewItems();
                    addNewItems.Show();
                    this.Hide();
                }
                else
                {

                    MessageBox.Show("Please Correct username or password");
                    txtUsername.Clear();
                    txtPass.Clear();

                }
            }

        }
    }
}
