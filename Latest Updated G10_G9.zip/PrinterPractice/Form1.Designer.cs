﻿namespace PrinterPractice
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            lblItem = new Label();
            txtQty = new TextBox();
            lblQty = new Label();
            txtPrice = new TextBox();
            lblPrice = new Label();
            btnCart = new Button();
            btnOrder = new Button();
            dataGridViewItems = new DataGridView();
            btnCancel = new Button();
            txtAmount = new TextBox();
            txtSaleTax = new TextBox();
            txtTotalPay = new TextBox();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            printPreviewDialog1 = new PrintPreviewDialog();
            contextMenuStrip1 = new ContextMenuStrip(components);
            deleteToolStripMenuItem = new ToolStripMenuItem();
            bxEmployee = new ComboBox();
            btnNewItemAdd = new Button();
            txtItems = new TextBox();
            listBoxSuggestions = new ListBox();
            btnRefresh = new Button();
            btnNewSaleMan = new Button();
            lblGetPayment = new Label();
            lblGivePayment = new Label();
            txtGetPayment = new TextBox();
            txtGivePayment = new TextBox();
            backGradiant1 = new BackGradiant();
            label11 = new Label();
            label10 = new Label();
            txtSubTotal = new TextBox();
            txtExtraDisc = new TextBox();
            label9 = new Label();
            panel2 = new Panel();
            panel1 = new Panel();
            btnFormClose = new Panel();
            btnPreview = new Button();
            txtAfterDisc = new TextBox();
            lblDiscValue = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewItems).BeginInit();
            contextMenuStrip1.SuspendLayout();
            backGradiant1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(25, 55);
            label1.Name = "label1";
            label1.Size = new Size(121, 16);
            label1.TabIndex = 3;
            label1.Text = "Salesman Name";
            // 
            // lblItem
            // 
            lblItem.AutoSize = true;
            lblItem.BackColor = Color.Transparent;
            lblItem.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            lblItem.ForeColor = Color.FromArgb(64, 64, 64);
            lblItem.Location = new Point(28, 104);
            lblItem.Name = "lblItem";
            lblItem.Size = new Size(81, 16);
            lblItem.TabIndex = 3;
            lblItem.Text = "Item Name";
            // 
            // txtQty
            // 
            txtQty.BackColor = Color.AliceBlue;
            txtQty.BorderStyle = BorderStyle.None;
            txtQty.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            txtQty.Location = new Point(291, 128);
            txtQty.Multiline = true;
            txtQty.Name = "txtQty";
            txtQty.Size = new Size(79, 27);
            txtQty.TabIndex = 1;
            txtQty.TextChanged += txtQty_TextChanged;
            txtQty.KeyDown += txtQty_KeyDown;
            txtQty.KeyPress += txtQty_KeyPress;
            // 
            // lblQty
            // 
            lblQty.AutoSize = true;
            lblQty.BackColor = Color.Transparent;
            lblQty.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            lblQty.ForeColor = Color.FromArgb(64, 64, 64);
            lblQty.Location = new Point(295, 104);
            lblQty.Name = "lblQty";
            lblQty.Size = new Size(63, 16);
            lblQty.TabIndex = 3;
            lblQty.Text = "Quantity";
            // 
            // txtPrice
            // 
            txtPrice.BackColor = Color.AliceBlue;
            txtPrice.BorderStyle = BorderStyle.None;
            txtPrice.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            txtPrice.Location = new Point(396, 128);
            txtPrice.Multiline = true;
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(111, 27);
            txtPrice.TabIndex = 2;
            txtPrice.KeyDown += txtPrice_KeyDown;
            txtPrice.KeyPress += txtPrice_KeyPress;
            // 
            // lblPrice
            // 
            lblPrice.AutoSize = true;
            lblPrice.BackColor = Color.Transparent;
            lblPrice.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            lblPrice.ForeColor = Color.FromArgb(64, 64, 64);
            lblPrice.Location = new Point(396, 104);
            lblPrice.Name = "lblPrice";
            lblPrice.Size = new Size(73, 16);
            lblPrice.TabIndex = 3;
            lblPrice.Text = "Unit price";
            // 
            // btnCart
            // 
            btnCart.BackColor = Color.AliceBlue;
            btnCart.BackgroundImageLayout = ImageLayout.Zoom;
            btnCart.Cursor = Cursors.Hand;
            btnCart.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            btnCart.ForeColor = Color.MidnightBlue;
            btnCart.Image = (Image)resources.GetObject("btnCart.Image");
            btnCart.ImageAlign = ContentAlignment.MiddleLeft;
            btnCart.Location = new Point(645, 114);
            btnCart.Name = "btnCart";
            btnCart.Size = new Size(81, 45);
            btnCart.TabIndex = 4;
            btnCart.Text = "Cart";
            btnCart.TextAlign = ContentAlignment.MiddleRight;
            btnCart.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnCart.UseVisualStyleBackColor = false;
            btnCart.Click += btnCart_Click;
            // 
            // btnOrder
            // 
            btnOrder.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnOrder.BackColor = Color.LimeGreen;
            btnOrder.Cursor = Cursors.Hand;
            btnOrder.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnOrder.ForeColor = Color.AliceBlue;
            btnOrder.Image = (Image)resources.GetObject("btnOrder.Image");
            btnOrder.ImageAlign = ContentAlignment.MiddleLeft;
            btnOrder.Location = new Point(817, 48);
            btnOrder.Name = "btnOrder";
            btnOrder.Size = new Size(122, 47);
            btnOrder.TabIndex = 0;
            btnOrder.Text = "    New Bill";
            btnOrder.UseVisualStyleBackColor = false;
            btnOrder.Click += btnOrder_Click;
            btnOrder.MouseClick += button4_MouseClick;
            // 
            // dataGridViewItems
            // 
            dataGridViewItems.AllowUserToAddRows = false;
            dataGridViewItems.AllowUserToDeleteRows = false;
            dataGridViewItems.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridViewItems.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewItems.BackgroundColor = Color.Honeydew;
            dataGridViewItems.BorderStyle = BorderStyle.None;
            dataGridViewItems.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewItems.Location = new Point(291, 188);
            dataGridViewItems.Name = "dataGridViewItems";
            dataGridViewItems.ReadOnly = true;
            dataGridViewItems.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewItems.Size = new Size(650, 181);
            dataGridViewItems.TabIndex = 13;
            dataGridViewItems.CellContentClick += dataGridViewItems_CellContentClick;
            dataGridViewItems.MouseDown += dataGridViewItems_MouseDown;
            // 
            // btnCancel
            // 
            btnCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnCancel.BackColor = Color.Red;
            btnCancel.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            btnCancel.ForeColor = Color.AliceBlue;
            btnCancel.Image = (Image)resources.GetObject("btnCancel.Image");
            btnCancel.ImageAlign = ContentAlignment.MiddleLeft;
            btnCancel.Location = new Point(23, 442);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(114, 45);
            btnCancel.TabIndex = 11;
            btnCancel.Text = "Cancel Bill";
            btnCancel.TextAlign = ContentAlignment.MiddleRight;
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // txtAmount
            // 
            txtAmount.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            txtAmount.BackColor = Color.AliceBlue;
            txtAmount.BorderStyle = BorderStyle.None;
            txtAmount.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            txtAmount.Location = new Point(575, 383);
            txtAmount.Multiline = true;
            txtAmount.Name = "txtAmount";
            txtAmount.ReadOnly = true;
            txtAmount.Size = new Size(122, 26);
            txtAmount.TabIndex = 6;
            txtAmount.TextChanged += txtAmount_TextChanged;
            txtAmount.KeyPress += txtAmount_KeyPress;
            // 
            // txtSaleTax
            // 
            txtSaleTax.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            txtSaleTax.BackColor = Color.AliceBlue;
            txtSaleTax.BorderStyle = BorderStyle.None;
            txtSaleTax.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            txtSaleTax.Location = new Point(575, 422);
            txtSaleTax.Multiline = true;
            txtSaleTax.Name = "txtSaleTax";
            txtSaleTax.Size = new Size(122, 26);
            txtSaleTax.TabIndex = 5;
            txtSaleTax.TextChanged += txtSaleTax_TextChanged;
            txtSaleTax.KeyPress += txtSaleTax_KeyPress;
            // 
            // txtTotalPay
            // 
            txtTotalPay.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            txtTotalPay.BackColor = Color.AliceBlue;
            txtTotalPay.BorderStyle = BorderStyle.None;
            txtTotalPay.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            txtTotalPay.Location = new Point(575, 460);
            txtTotalPay.Multiline = true;
            txtTotalPay.Name = "txtTotalPay";
            txtTotalPay.ReadOnly = true;
            txtTotalPay.Size = new Size(122, 26);
            txtTotalPay.TabIndex = 8;
            txtTotalPay.TextChanged += txtTotalPay_TextChanged;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            label5.ForeColor = Color.FromArgb(64, 64, 64);
            label5.Location = new Point(480, 387);
            label5.Name = "label5";
            label5.Size = new Size(88, 16);
            label5.TabIndex = 3;
            label5.Text = "Gross Total";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            label6.ForeColor = Color.FromArgb(64, 64, 64);
            label6.Location = new Point(485, 426);
            label6.Name = "label6";
            label6.Size = new Size(67, 16);
            label6.TabIndex = 3;
            label6.Text = "Discount";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            label7.ForeColor = Color.FromArgb(64, 64, 64);
            label7.Location = new Point(485, 464);
            label7.Name = "label7";
            label7.Size = new Size(71, 16);
            label7.TabIndex = 3;
            label7.Text = "Net Totat";
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage;
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { deleteToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(108, 26);
            contextMenuStrip1.Opening += contextMenuStrip1_Opening;
            // 
            // deleteToolStripMenuItem
            // 
            deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            deleteToolStripMenuItem.Size = new Size(107, 22);
            deleteToolStripMenuItem.Text = "Delete";
            deleteToolStripMenuItem.Click += deleteToolStripMenuItem_Click;
            // 
            // bxEmployee
            // 
            bxEmployee.BackColor = Color.AliceBlue;
            bxEmployee.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            bxEmployee.FormattingEnabled = true;
            bxEmployee.Location = new Point(152, 52);
            bxEmployee.Name = "bxEmployee";
            bxEmployee.Size = new Size(218, 23);
            bxEmployee.TabIndex = 7;
            // 
            // btnNewItemAdd
            // 
            btnNewItemAdd.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnNewItemAdd.BackColor = Color.AliceBlue;
            btnNewItemAdd.Cursor = Cursors.Hand;
            btnNewItemAdd.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            btnNewItemAdd.ForeColor = Color.MidnightBlue;
            btnNewItemAdd.Image = (Image)resources.GetObject("btnNewItemAdd.Image");
            btnNewItemAdd.ImageAlign = ContentAlignment.MiddleLeft;
            btnNewItemAdd.Location = new Point(817, 97);
            btnNewItemAdd.Name = "btnNewItemAdd";
            btnNewItemAdd.Size = new Size(124, 41);
            btnNewItemAdd.TabIndex = 9;
            btnNewItemAdd.Text = "New item";
            btnNewItemAdd.TextAlign = ContentAlignment.MiddleRight;
            btnNewItemAdd.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnNewItemAdd.UseVisualStyleBackColor = false;
            btnNewItemAdd.Click += btnNewItemAdd_Click;
            btnNewItemAdd.MouseClick += btnNewItemAdd_MouseClick;
            // 
            // txtItems
            // 
            txtItems.BackColor = Color.AliceBlue;
            txtItems.BorderStyle = BorderStyle.None;
            txtItems.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            txtItems.Location = new Point(25, 128);
            txtItems.Multiline = true;
            txtItems.Name = "txtItems";
            txtItems.Size = new Size(218, 27);
            txtItems.TabIndex = 0;
            txtItems.Click += txtItems_Click;
            txtItems.TextChanged += txtItems_TextChanged;
            txtItems.KeyDown += txtItems_KeyDown;
            // 
            // listBoxSuggestions
            // 
            listBoxSuggestions.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            listBoxSuggestions.BackColor = Color.Honeydew;
            listBoxSuggestions.BorderStyle = BorderStyle.None;
            listBoxSuggestions.FormattingEnabled = true;
            listBoxSuggestions.ItemHeight = 15;
            listBoxSuggestions.Location = new Point(25, 189);
            listBoxSuggestions.Name = "listBoxSuggestions";
            listBoxSuggestions.Size = new Size(218, 180);
            listBoxSuggestions.TabIndex = 13;
            listBoxSuggestions.MouseClick += listBoxSuggestions_MouseClick;
            listBoxSuggestions.KeyDown += listBoxSuggestions_KeyDown;
            listBoxSuggestions.KeyPress += listBoxSuggestions_KeyPress;
            // 
            // btnRefresh
            // 
            btnRefresh.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnRefresh.BackColor = Color.AliceBlue;
            btnRefresh.Cursor = Cursors.Hand;
            btnRefresh.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            btnRefresh.ForeColor = Color.MidnightBlue;
            btnRefresh.Image = (Image)resources.GetObject("btnRefresh.Image");
            btnRefresh.ImageAlign = ContentAlignment.MiddleLeft;
            btnRefresh.Location = new Point(817, 144);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(124, 37);
            btnRefresh.TabIndex = 10;
            btnRefresh.Text = " Refresh";
            btnRefresh.UseVisualStyleBackColor = false;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // btnNewSaleMan
            // 
            btnNewSaleMan.BackColor = Color.AliceBlue;
            btnNewSaleMan.Cursor = Cursors.Hand;
            btnNewSaleMan.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            btnNewSaleMan.ForeColor = Color.MidnightBlue;
            btnNewSaleMan.Image = (Image)resources.GetObject("btnNewSaleMan.Image");
            btnNewSaleMan.ImageAlign = ContentAlignment.MiddleLeft;
            btnNewSaleMan.Location = new Point(386, 40);
            btnNewSaleMan.Name = "btnNewSaleMan";
            btnNewSaleMan.Size = new Size(149, 45);
            btnNewSaleMan.TabIndex = 8;
            btnNewSaleMan.Text = "New Sales Man";
            btnNewSaleMan.TextAlign = ContentAlignment.MiddleRight;
            btnNewSaleMan.UseVisualStyleBackColor = false;
            btnNewSaleMan.MouseClick += btnNewSaleMan_MouseClick;
            // 
            // lblGetPayment
            // 
            lblGetPayment.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            lblGetPayment.AutoSize = true;
            lblGetPayment.BackColor = Color.Transparent;
            lblGetPayment.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            lblGetPayment.ForeColor = Color.FromArgb(64, 64, 64);
            lblGetPayment.Location = new Point(716, 389);
            lblGetPayment.Name = "lblGetPayment";
            lblGetPayment.Size = new Size(95, 16);
            lblGetPayment.TabIndex = 15;
            lblGetPayment.Text = "Get Payment";
            // 
            // lblGivePayment
            // 
            lblGivePayment.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            lblGivePayment.AutoSize = true;
            lblGivePayment.BackColor = Color.Transparent;
            lblGivePayment.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            lblGivePayment.ForeColor = Color.FromArgb(64, 64, 64);
            lblGivePayment.Location = new Point(709, 428);
            lblGivePayment.Name = "lblGivePayment";
            lblGivePayment.Size = new Size(103, 16);
            lblGivePayment.TabIndex = 15;
            lblGivePayment.Text = "Give Payment";
            // 
            // txtGetPayment
            // 
            txtGetPayment.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            txtGetPayment.BackColor = Color.AliceBlue;
            txtGetPayment.BorderStyle = BorderStyle.None;
            txtGetPayment.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            txtGetPayment.Location = new Point(817, 383);
            txtGetPayment.Multiline = true;
            txtGetPayment.Name = "txtGetPayment";
            txtGetPayment.Size = new Size(122, 26);
            txtGetPayment.TabIndex = 6;
            txtGetPayment.TextChanged += txtGetPayment_TextChanged;
            txtGetPayment.KeyPress += txtGetPayment_KeyPress;
            // 
            // txtGivePayment
            // 
            txtGivePayment.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            txtGivePayment.BackColor = Color.AliceBlue;
            txtGivePayment.BorderStyle = BorderStyle.None;
            txtGivePayment.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            txtGivePayment.Location = new Point(817, 425);
            txtGivePayment.Multiline = true;
            txtGivePayment.Name = "txtGivePayment";
            txtGivePayment.ReadOnly = true;
            txtGivePayment.Size = new Size(122, 26);
            txtGivePayment.TabIndex = 6;
            // 
            // backGradiant1
            // 
            backGradiant1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            backGradiant1.BackColor = SystemColors.ButtonFace;
            backGradiant1.ColorBottom = Color.LightCyan;
            backGradiant1.ColorTop = Color.DarkTurquoise;
            backGradiant1.Controls.Add(label11);
            backGradiant1.Controls.Add(label10);
            backGradiant1.Controls.Add(txtSubTotal);
            backGradiant1.Controls.Add(txtExtraDisc);
            backGradiant1.Controls.Add(label9);
            backGradiant1.Controls.Add(panel2);
            backGradiant1.Controls.Add(panel1);
            backGradiant1.Controls.Add(btnFormClose);
            backGradiant1.Controls.Add(btnPreview);
            backGradiant1.Controls.Add(txtAfterDisc);
            backGradiant1.Controls.Add(label1);
            backGradiant1.Controls.Add(bxEmployee);
            backGradiant1.Controls.Add(lblGivePayment);
            backGradiant1.Controls.Add(btnNewSaleMan);
            backGradiant1.Controls.Add(lblGetPayment);
            backGradiant1.Controls.Add(btnCancel);
            backGradiant1.Controls.Add(label7);
            backGradiant1.Controls.Add(btnRefresh);
            backGradiant1.Controls.Add(label6);
            backGradiant1.Controls.Add(lblItem);
            backGradiant1.Controls.Add(label5);
            backGradiant1.Controls.Add(btnNewItemAdd);
            backGradiant1.Controls.Add(txtTotalPay);
            backGradiant1.Controls.Add(listBoxSuggestions);
            backGradiant1.Controls.Add(txtSaleTax);
            backGradiant1.Controls.Add(dataGridViewItems);
            backGradiant1.Controls.Add(txtGivePayment);
            backGradiant1.Controls.Add(txtItems);
            backGradiant1.Controls.Add(txtGetPayment);
            backGradiant1.Controls.Add(lblQty);
            backGradiant1.Controls.Add(txtAmount);
            backGradiant1.Controls.Add(txtQty);
            backGradiant1.Controls.Add(btnCart);
            backGradiant1.Controls.Add(lblDiscValue);
            backGradiant1.Controls.Add(lblPrice);
            backGradiant1.Controls.Add(txtPrice);
            backGradiant1.Controls.Add(btnOrder);
            backGradiant1.Location = new Point(0, -1);
            backGradiant1.Name = "backGradiant1";
            backGradiant1.Size = new Size(967, 507);
            backGradiant1.TabIndex = 16;
            backGradiant1.Paint += backGradiant1_Paint;
            backGradiant1.MouseClick += backGradiant1_MouseClick;
            backGradiant1.MouseDown += backGradiant1_MouseDown;
            backGradiant1.MouseMove += backGradiant1_MouseMove;
            backGradiant1.MouseUp += backGradiant1_MouseUp;
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            label11.ForeColor = Color.FromArgb(64, 64, 64);
            label11.Location = new Point(281, 439);
            label11.Name = "label11";
            label11.Size = new Size(74, 16);
            label11.TabIndex = 23;
            label11.Text = "Sub Total";
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            label10.ForeColor = Color.FromArgb(64, 64, 64);
            label10.Location = new Point(281, 389);
            label10.Name = "label10";
            label10.Size = new Size(77, 16);
            label10.TabIndex = 22;
            label10.Text = "Extra Disc";
            // 
            // txtSubTotal
            // 
            txtSubTotal.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            txtSubTotal.BackColor = Color.AliceBlue;
            txtSubTotal.BorderStyle = BorderStyle.None;
            txtSubTotal.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            txtSubTotal.Location = new Point(365, 429);
            txtSubTotal.Multiline = true;
            txtSubTotal.Name = "txtSubTotal";
            txtSubTotal.ReadOnly = true;
            txtSubTotal.Size = new Size(104, 26);
            txtSubTotal.TabIndex = 21;
            // 
            // txtExtraDisc
            // 
            txtExtraDisc.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            txtExtraDisc.BackColor = Color.AliceBlue;
            txtExtraDisc.BorderStyle = BorderStyle.None;
            txtExtraDisc.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            txtExtraDisc.Location = new Point(365, 383);
            txtExtraDisc.Multiline = true;
            txtExtraDisc.Name = "txtExtraDisc";
            txtExtraDisc.PlaceholderText = "0";
            txtExtraDisc.Size = new Size(104, 26);
            txtExtraDisc.TabIndex = 20;
            txtExtraDisc.KeyPress += txtExtraDisc_KeyPress;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Broadway", 18F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.Teal;
            label9.Location = new Point(9, 11);
            label9.Name = "label9";
            label9.Size = new Size(214, 27);
            label9.TabIndex = 19;
            label9.Text = "At.Son Software";
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            panel2.BackColor = Color.Transparent;
            panel2.BackgroundImage = (Image)resources.GetObject("panel2.BackgroundImage");
            panel2.BackgroundImageLayout = ImageLayout.Stretch;
            panel2.Cursor = Cursors.Hand;
            panel2.Location = new Point(848, 2);
            panel2.Name = "panel2";
            panel2.Size = new Size(35, 35);
            panel2.TabIndex = 18;
            panel2.MouseClick += panel2_MouseClick;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            panel1.BackColor = Color.Transparent;
            panel1.BackgroundImage = (Image)resources.GetObject("panel1.BackgroundImage");
            panel1.BackgroundImageLayout = ImageLayout.Stretch;
            panel1.Cursor = Cursors.Hand;
            panel1.Location = new Point(890, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(35, 35);
            panel1.TabIndex = 18;
            panel1.MouseClick += panel1_MouseClick;
            // 
            // btnFormClose
            // 
            btnFormClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnFormClose.BackColor = Color.Transparent;
            btnFormClose.BackgroundImage = (Image)resources.GetObject("btnFormClose.BackgroundImage");
            btnFormClose.BackgroundImageLayout = ImageLayout.Stretch;
            btnFormClose.Cursor = Cursors.Hand;
            btnFormClose.Location = new Point(932, 1);
            btnFormClose.Name = "btnFormClose";
            btnFormClose.Size = new Size(35, 35);
            btnFormClose.TabIndex = 17;
            btnFormClose.MouseClick += btnFormClose_MouseClick;
            // 
            // btnPreview
            // 
            btnPreview.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnPreview.BackColor = SystemColors.ActiveCaptionText;
            btnPreview.Font = new Font("Showcard Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPreview.ForeColor = SystemColors.ButtonHighlight;
            btnPreview.Image = (Image)resources.GetObject("btnPreview.Image");
            btnPreview.ImageAlign = ContentAlignment.TopCenter;
            btnPreview.Location = new Point(896, 473);
            btnPreview.Name = "btnPreview";
            btnPreview.Size = new Size(45, 26);
            btnPreview.TabIndex = 16;
            btnPreview.Text = "P";
            btnPreview.UseVisualStyleBackColor = false;
            btnPreview.Click += btnPreview_Click_3;
            // 
            // txtAfterDisc
            // 
            txtAfterDisc.BackColor = Color.AliceBlue;
            txtAfterDisc.BorderStyle = BorderStyle.None;
            txtAfterDisc.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtAfterDisc.Location = new Point(526, 128);
            txtAfterDisc.Multiline = true;
            txtAfterDisc.Name = "txtAfterDisc";
            txtAfterDisc.Size = new Size(100, 27);
            txtAfterDisc.TabIndex = 3;
            txtAfterDisc.KeyPress += txtAfterDisc_KeyPress;
            // 
            // lblDiscValue
            // 
            lblDiscValue.AutoSize = true;
            lblDiscValue.BackColor = Color.Transparent;
            lblDiscValue.Font = new Font("Microsoft Sans Serif", 9.75F, FontStyle.Bold);
            lblDiscValue.ForeColor = Color.FromArgb(64, 64, 64);
            lblDiscValue.Location = new Point(526, 104);
            lblDiscValue.Name = "lblDiscValue";
            lblDiscValue.Size = new Size(82, 16);
            lblDiscValue.TabIndex = 3;
            lblDiscValue.Text = "Disc Value";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlDarkDark;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(967, 505);
            Controls.Add(backGradiant1);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AT.Son Softwares";
            Load += Form1_Load;
            KeyDown += Form1_KeyDown;
            ((System.ComponentModel.ISupportInitialize)dataGridViewItems).EndInit();
            contextMenuStrip1.ResumeLayout(false);
            backGradiant1.ResumeLayout(false);
            backGradiant1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Label label1;
        private Label lblItem;
        private TextBox txtQty;
        private Label lblQty;
        private TextBox txtPrice;
        private Label lblPrice;
        private Button btnCart;
        private Button btnOrder;
        private DataGridView dataGridViewItems;
        private Button btnCancel;
        private TextBox txtAmount;
        private TextBox txtSaleTax;
        private TextBox txtTotalPay;
        private Label label5;
        private Label label6;
        private Label label7;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private PrintPreviewDialog printPreviewDialog1;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ComboBox bxEmployee;
        private Button btnNewItemAdd;
        private TextBox txtItems;
        private ListBox listBoxSuggestions;
        private Button btnRefresh;
        private Button btnNewSaleMan;
        private Label lblGetPayment;
        private Label lblGivePayment;
        private TextBox txtGetPayment;
        private TextBox txtGivePayment;
        private BackGradiant backGradiant1;
        private TextBox txtAfterDisc;
        private Label lblDiscValue;
        private Button btnPreview;
        private Panel btnFormClose;
        private Panel panel2;
        private Panel panel1;
        private Label label9;
        private Label label10;
        private TextBox txtSubTotal;
        private TextBox txtExtraDisc;
        private Label label11;
    }
}
