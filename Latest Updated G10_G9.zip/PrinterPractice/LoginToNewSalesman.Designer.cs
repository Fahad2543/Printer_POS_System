﻿namespace PrinterPractice
{
    partial class LoginToNewSalesman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginToNewSalesman));
            btnLoginSaleMan = new Button();
            txtPassSales = new TextBox();
            label3 = new Label();
            txtUsernameSales = new TextBox();
            label2 = new Label();
            label1 = new Label();
            backGradiant1 = new BackGradiant();
            backGradiant1.SuspendLayout();
            SuspendLayout();
            // 
            // btnLoginSaleMan
            // 
            btnLoginSaleMan.BackColor = Color.White;
            btnLoginSaleMan.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLoginSaleMan.ForeColor = Color.MidnightBlue;
            btnLoginSaleMan.Location = new Point(150, 152);
            btnLoginSaleMan.Name = "btnLoginSaleMan";
            btnLoginSaleMan.Size = new Size(124, 37);
            btnLoginSaleMan.TabIndex = 8;
            btnLoginSaleMan.Text = "Login";
            btnLoginSaleMan.UseVisualStyleBackColor = false;
            btnLoginSaleMan.Click += btnLoginSaleMan_Click;
            btnLoginSaleMan.MouseClick += btnLoginSaleMan_MouseClick;
            // 
            // txtPassSales
            // 
            txtPassSales.Font = new Font("Bahnschrift", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPassSales.Location = new Point(150, 101);
            txtPassSales.Name = "txtPassSales";
            txtPassSales.Size = new Size(157, 27);
            txtPassSales.TabIndex = 7;
            txtPassSales.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Bahnschrift", 12F);
            label3.ForeColor = Color.White;
            label3.Location = new Point(60, 104);
            label3.Name = "label3";
            label3.Size = new Size(81, 19);
            label3.TabIndex = 3;
            label3.Text = "Password";
            // 
            // txtUsernameSales
            // 
            txtUsernameSales.Font = new Font("Bahnschrift", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUsernameSales.Location = new Point(150, 56);
            txtUsernameSales.Name = "txtUsernameSales";
            txtUsernameSales.Size = new Size(157, 27);
            txtUsernameSales.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Bahnschrift", 12F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(60, 59);
            label2.Name = "label2";
            label2.Size = new Size(84, 19);
            label2.TabIndex = 5;
            label2.Text = "Username";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Bahnschrift", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.IndianRed;
            label1.Location = new Point(150, 9);
            label1.Name = "label1";
            label1.Size = new Size(147, 29);
            label1.TabIndex = 6;
            label1.Text = "Admin Login";
            // 
            // backGradiant1
            // 
            backGradiant1.ColorBottom = Color.LightCyan;
            backGradiant1.ColorTop = Color.DarkTurquoise;
            backGradiant1.Controls.Add(label1);
            backGradiant1.Controls.Add(btnLoginSaleMan);
            backGradiant1.Controls.Add(label2);
            backGradiant1.Controls.Add(txtPassSales);
            backGradiant1.Controls.Add(txtUsernameSales);
            backGradiant1.Controls.Add(label3);
            backGradiant1.Location = new Point(1, 0);
            backGradiant1.Name = "backGradiant1";
            backGradiant1.Size = new Size(458, 203);
            backGradiant1.TabIndex = 9;
            // 
            // LoginToNewSalesman
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(459, 201);
            Controls.Add(backGradiant1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "LoginToNewSalesman";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin Login";
            backGradiant1.ResumeLayout(false);
            backGradiant1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btnLoginSaleMan;
        private TextBox txtPassSales;
        private Label label3;
        private TextBox txtUsernameSales;
        private Label label2;
        private Label label1;
        private BackGradiant backGradiant1;
    }
}