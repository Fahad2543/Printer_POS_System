using PrinterPractice.Models;
using PrinterPractice.Properties;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PrinterPractice
{
    public partial class Form1 : Form
    {
        private List<string> items;
        private bool isFullscreen = false;
        private FormBorderStyle originalFormBorderStyle;
        private Rectangle originalFormBounds;
        private bool isDragging = false;
        private Point startPoint = new Point(0, 0);
        public Form1()
        {
            InitializeComponent();
            // Attach KeyDown event handlers for Enter key functionality
            AttachKeyDownEventHandlers();
            LoadItems();
            this.KeyPreview = true; // Ensure that the form captures key events
            txtExtraDisc.TextChanged += txtExtraDisc_TextChanged;
            backGradiant1.SendToBack();

        }



        private void LoadEmployees()
        {
            try
            {
                // Define relative path to your file in the project
                string fileName = "NewSaleMan.txt";
                // Resolve the absolute path
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);

                if (File.Exists(filePath))
                {
                    string[] salesMen = File.ReadAllLines(filePath);

                    // Display sales men in a ListBox (or any other control)
                    foreach (string salesMan in salesMen)
                    {
                        if (!string.IsNullOrWhiteSpace(salesMan))
                        {
                            bxEmployee.Items.Add(salesMan.Trim());
                        }
                    }
                }
                else
                {
                    MessageBox.Show($"The file '{filePath}' does not exist.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void LoadItems()
        {
            try
            {
                string[] lines = File.ReadAllLines("items.txt");
                items = lines.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: no data found! " + ex.Message);
            }
        }



        private List<CartItem> shopingCart = new List<CartItem>();

        private void AttachKeyDownEventHandlers()
        {
            txtQty.KeyDown += new KeyEventHandler(OnEnterKeyPress);
            txtPrice.KeyDown += new KeyEventHandler(OnEnterKeyPress);
            txtItems.KeyDown += new KeyEventHandler(OnEnterKeyPress);
        }

        private void OnEnterKeyPress(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnCart_Click(sender, e); // "Add to Cart" function call
                e.Handled = true;  // Event ko handle kar rahe hain
                e.SuppressKeyPress = true;  // Enter key press ko suppress kar rahe hain
            }
        }

        private void button4_MouseClick(object sender, MouseEventArgs e)
        {
            // Code for button4_MouseClick event
        }
        /*
       private void btnCart_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtItems.Text) ||
                string.IsNullOrWhiteSpace(txtQty.Text) ||
                string.IsNullOrWhiteSpace(txtPrice.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                if (string.IsNullOrWhiteSpace(txtItems.Text))
                {
                    txtItems.Focus();
                }
                else if (string.IsNullOrWhiteSpace(txtQty.Text))
                {
                    txtQty.Focus();
                }
                else if (string.IsNullOrWhiteSpace(txtPrice.Text))
                {
                    txtPrice.Focus();
                }
                return;
            }

            if (!decimal.TryParse(txtQty.Text.Trim(), out decimal quantity) ||
                !decimal.TryParse(txtPrice.Text.Trim(), out decimal unitPrice))
            {
                MessageBox.Show("Please enter valid numbers for Quantity and Price.");
                return;
            }

            decimal? afterDisc = null;
            if (!string.IsNullOrWhiteSpace(txtAfterDisc.Text))
            {
                if (!decimal.TryParse(txtAfterDisc.Text.Trim(), out decimal tempAfterDisc))
                {
                    MessageBox.Show("Please enter a valid number for After Discount.");
                    return;
                }
                afterDisc = tempAfterDisc;
            }

            CartItem item = new CartItem()
            {
                ItemName = txtItems.Text.Trim(),
                Quantity = quantity,
                UnitPrice = unitPrice,
                Total_Price = quantity * unitPrice,
                After_Disc = afterDisc
            };
            shopingCart.Add(item);
            dataGridViewItems.DataSource = null;
            dataGridViewItems.DataSource = shopingCart;

            decimal totalAmount = shopingCart.Sum(x => x.Total_Price);
            txtAmount.Text = totalAmount.ToString();

            decimal saleTax = 0;
            if (!string.IsNullOrWhiteSpace(txtSaleTax.Text) &&
                decimal.TryParse(txtSaleTax.Text.Trim(), out saleTax))
            {
                saleTax = saleTax;
            }
            decimal totalPayable = totalAmount - saleTax;

            txtTotalPay.Text = totalPayable.ToString();

            txtItems.Clear();
            txtQty.Clear();
            txtPrice.Clear();
            txtAfterDisc.Clear();

            listBoxSuggestions.Visible = true;
            listBoxSuggestions.BringToFront();
            txtItems.Focus();
            KeyEventArgs keyEvent = new KeyEventArgs(Keys.Down);
            txtItems_KeyDown(sender, keyEvent);
        }
        */

        private void btnCart_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtItems.Text) ||
                string.IsNullOrWhiteSpace(txtQty.Text) ||
                string.IsNullOrWhiteSpace(txtPrice.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                if (string.IsNullOrWhiteSpace(txtItems.Text))
                {
                    txtItems.Focus();
                }
                else if (string.IsNullOrWhiteSpace(txtQty.Text))
                {
                    txtQty.Focus();
                }
                else if (string.IsNullOrWhiteSpace(txtPrice.Text))
                {
                    txtPrice.Focus();
                }
                return;
            }

            if (!decimal.TryParse(txtQty.Text.Trim(), out decimal quantity) ||
                !decimal.TryParse(txtPrice.Text.Trim(), out decimal unitPrice))
            {
                MessageBox.Show("Please enter valid numbers for Quantity and Price.");
                return;
            }

            decimal? afterDisc = null;
            if (!string.IsNullOrWhiteSpace(txtAfterDisc.Text))
            {
                if (!decimal.TryParse(txtAfterDisc.Text.Trim(), out decimal tempAfterDisc))
                {
                    MessageBox.Show("Please enter a valid number for After Discount.");
                    return;
                }
                afterDisc = tempAfterDisc;
            }

            CartItem item = new CartItem()
            {
                ItemName = txtItems.Text.Trim(),
                Quantity = quantity,
                UnitPrice = unitPrice,
                Total_Price = quantity * unitPrice,
                After_Disc = afterDisc,
                After_Disc_Total = (afterDisc.HasValue && afterDisc.Value != 0) ? afterDisc.Value * quantity : quantity * unitPrice // Ensure After_Disc_Total is set
            };
            shopingCart.Add(item);
            dataGridViewItems.DataSource = null;
            dataGridViewItems.DataSource = shopingCart;

            CalculateGrossTotal(); // Recalculate the totals after adding a new row

            decimal totalAmount = shopingCart.Sum(x => x.Total_Price);
            txtAmount.Text = totalAmount.ToString();

            decimal disct = 0;
            if (!string.IsNullOrWhiteSpace(txtSaleTax.Text) &&
                decimal.TryParse(txtSaleTax.Text.Trim(), out decimal saleTax))
            {
                disct = saleTax;
            }
            decimal disc = totalAmount - disct;

            txtTotalPay.Text = disc.ToString();

            txtItems.Clear();
            txtQty.Clear();
            txtPrice.Clear();
            txtAfterDisc.Clear();
            txtSubTotal.Clear();

            listBoxSuggestions.Visible = true;
            listBoxSuggestions.BringToFront();
            txtItems.Focus();
            KeyEventArgs keyEvent = new KeyEventArgs(Keys.Down);
            txtItems_KeyDown(sender, keyEvent);
        }

        private void CalculateGrossTotal()
        {
            try
            {
                decimal grossTotal = 0;
                decimal totalSaleTax = 0;

                foreach (DataGridViewRow row in dataGridViewItems.Rows)
                {
                    if (row.Cells["Total_Price"].Value != null &&
                        decimal.TryParse(row.Cells["Total_Price"].Value.ToString(), out decimal totalPriceValue))
                    {
                        grossTotal += totalPriceValue;

                        decimal afterDiscValue = 0;
                        if (row.Cells["After_Disc"].Value != null && !string.IsNullOrEmpty(row.Cells["After_Disc"].Value.ToString()))
                        {
                            decimal.TryParse(row.Cells["After_Disc"].Value.ToString(), out afterDiscValue);
                        }

                        decimal quantityValue = 0;
                        if (decimal.TryParse(row.Cells["Quantity"].Value.ToString(), out quantityValue))
                        {
                            decimal afterDiscTotal;
                            if (afterDiscValue != 0)
                            {
                                afterDiscTotal = afterDiscValue * quantityValue;
                                row.Cells["After_Disc_Total"].Value = afterDiscTotal;

                                decimal saleTax = totalPriceValue - afterDiscTotal;
                                totalSaleTax += saleTax;
                            }
                            else
                            {
                                afterDiscTotal = totalPriceValue;
                                row.Cells["After_Disc_Total"].Value = afterDiscTotal;
                            }
                        }
                    }
                }

                txtAmount.Text = grossTotal.ToString();
                txtSaleTax.Text = totalSaleTax.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }





        private static int invoiceCounter = 1;

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            // Assuming a 3-inch width (approximately 300 pixels at 100 DPI)
            float width = 400;

            // Adjusting fonts for better readability
            Font fontTitle = new Font("Arial", 22, FontStyle.Bold);
            string invoiceNumber = "Invoice_No: " + invoiceCounter++;
            int Dtxt = 180;
            int gridDataH = 230;

            // Printing shop name and address
            e.Graphics.DrawString("Nazir Fabrics", fontTitle, Brushes.Black, new Point(43, 5));
            e.Graphics.DrawString("Ladies and Gents variety house", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(67, 43));
            e.Graphics.DrawString("Azeem plaza, G10 Markaz,Islamabad", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(56, 60));
            e.Graphics.DrawString("Contact # 0332-9697962,", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(78, 80));
            e.Graphics.DrawString("0346-5500300.", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(105, 100));
            e.Graphics.DrawString(invoiceNumber, new Font("Arial", 10, FontStyle.Bold), Brushes.Black, new Point(10, 130));
            e.Graphics.DrawString("Sales Man: " + bxEmployee.Text, new Font("Arial", 9, FontStyle.Regular), Brushes.Black, new Point(10, 150));
            e.Graphics.DrawString("Date: " + DateTime.Now.ToShortDateString(), new Font("Arial", 9, FontStyle.Regular), Brushes.Black, new Point(Dtxt, 150));
            e.Graphics.DrawString("Time: " + DateTime.Now.ToShortTimeString(), new Font("Arial", 9, FontStyle.Regular), Brushes.Black, new Point(Dtxt, 170));
            e.Graphics.DrawString("Cash Sale ", new Font("Arial", 9, FontStyle.Regular), Brushes.Black, new Point(10, 170));
            e.Graphics.DrawString("________________________________________", new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(10, 190));
            e.Graphics.DrawString("Item Name", new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(10, 210));
            e.Graphics.DrawString("Qty", new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(110, 210));
            e.Graphics.DrawString("MRP ", new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(145, 210));
            e.Graphics.DrawString("Sale.P", new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(185, 210));
            e.Graphics.DrawString("Total", new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(Dtxt + 60, 210));
            e.Graphics.DrawString("________________________________________", new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(10, 225));

            // Set the width for item name column
            float itemNameWidth = 90; // Adjust this value as needed

            foreach (var i in shopingCart)
            {
                string itemName = i.ItemName;
                string remainingText = "";

                // Check if item name exceeds the column width
                if (e.Graphics.MeasureString(itemName, new Font("Arial", 8, FontStyle.Regular)).Width > itemNameWidth)
                {
                    // Split the text at the maximum width
                    int splitIndex = itemName.Length;
                    while (e.Graphics.MeasureString(itemName.Substring(0, splitIndex), new Font("Arial", 8, FontStyle.Regular)).Width > itemNameWidth)
                    {
                        splitIndex--;
                    }
                    remainingText = itemName.Substring(splitIndex);
                    itemName = itemName.Substring(0, splitIndex);
                }

                // Draw the item name
                e.Graphics.DrawString(itemName, new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(10, gridDataH + 20));
                e.Graphics.DrawString(i.Quantity.ToString(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(120, gridDataH + 20));
                e.Graphics.DrawString(i.UnitPrice.ToString(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(145, gridDataH + 20));
                e.Graphics.DrawString(i.After_Disc.ToString(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(185, gridDataH + 20));
                e.Graphics.DrawString(i.After_Disc_Total.ToString(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(Dtxt + 53, gridDataH + 20));

                // Move to the next line for the remaining text if exists
                if (!string.IsNullOrEmpty(remainingText))
                {
                    gridDataH += 20;
                    e.Graphics.DrawString(remainingText, new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(10, gridDataH + 20));
                }

                gridDataH += 20; // Move y position for the next item
            }

            // Draw the total number of items
            e.Graphics.DrawString("________________________________________", new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(10, gridDataH + 20));
            gridDataH += 20; // Move y position for the total number of items
            e.Graphics.DrawString("Total Items: " + shopingCart.Count, new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(10, gridDataH + 20));

            // Print Amount
            e.Graphics.DrawString("Gross Total: " + txtAmount.Text.Trim(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(165, gridDataH + 20));
            gridDataH += 20;

            // Print Sale Tax if it has a value
            if (!string.IsNullOrWhiteSpace(txtSaleTax.Text) && txtSaleTax.Text.Trim() != "0")
            {
                e.Graphics.DrawString("Discount:    " + txtSaleTax.Text.Trim(), new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(165, gridDataH + 20));
                gridDataH += 20;
            }

            // Print Total Pay
            e.Graphics.DrawString("Total Pay: " + txtTotalPay.Text.Trim(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(165, gridDataH + 20));
            gridDataH += 20;

            // Print Extra Disc if it has a value
            if (!string.IsNullOrWhiteSpace(txtExtraDisc.Text) && decimal.TryParse(txtExtraDisc.Text.Trim(), out decimal extraDisc) && extraDisc != 0)
            {
                e.Graphics.DrawString("Special Disc: " + txtExtraDisc.Text.Trim(), new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(165, gridDataH + 20));
                gridDataH += 20;
            }

            // Print SubTotal if it has a value
            if (!string.IsNullOrWhiteSpace(txtSubTotal.Text))
            {
                e.Graphics.DrawString("Sub Total: " + txtSubTotal.Text.Trim(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(165, gridDataH + 20));
                gridDataH += 20;
            }

            // Print Recieve and Balance
            e.Graphics.DrawString("Recieve:   " + txtGetPayment.Text.Trim(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(165, gridDataH + 20));
            gridDataH += 20;
            e.Graphics.DrawString("Balance:   " + txtGivePayment.Text.Trim(), new Font("Arial", 8, FontStyle.Regular), Brushes.Black, new Point(165, gridDataH + 20));
            gridDataH += 20;

            // Printing terms and conditions and other footer text
            e.Graphics.DrawString("Terms and Conditions:", new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(11, gridDataH + 20));
            e.Graphics.DrawString("- Purchased items can be exchanged with the original", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(10, gridDataH + 40));
            e.Graphics.DrawString("  bill within one week of the purchase date,but there", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(10, gridDataH + 55));
            e.Graphics.DrawString("  is no return policy.", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(10, gridDataH + 70));
            e.Graphics.DrawString("- No exchange or return policy applies to loose cut", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(10, gridDataH + 85));
            e.Graphics.DrawString("  fabric.", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(10, gridDataH + 100));
            e.Graphics.DrawString("- No claims will be accepted for suits after stitching.", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(10, gridDataH + 115));

            // Print Thank You message
            e.Graphics.DrawString("Thank you for Visiting.", new Font("Arial", 8, FontStyle.Bold), Brushes.Black, new Point(80, gridDataH + 140));
            e.Graphics.DrawString("( Computer Software developed by AT.Son Software Company", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(1, gridDataH + 160));
            e.Graphics.DrawString("  Phone # 0342-7111537 & 051-2727893 )", new Font("Arial", 7, FontStyle.Regular), Brushes.Black, new Point(1, gridDataH + 175));

            // End the print page
            e.HasMorePages = false;
        }







        private void btnPreview_Click(object sender, EventArgs e)
        {
            // printPreviewDialog1.Document = printDocument1;
            // printPreviewDialog1.ShowDialog();
        }

        private void txtCustomer_TextChanged(object sender, EventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnOrder.Enabled = true;
            btnCancel.Enabled = false;
            btnCart.Enabled = false;
            btnRefresh.Enabled = false;
            bxEmployee.Enabled = false;
            txtPrice.Enabled = false;
            txtAmount.Enabled = false;
            txtItems.Enabled = false;
            txtQty.Enabled = false;
            txtSaleTax.Enabled = false;
            txtTotalPay.Enabled = false;
            btnNewItemAdd.Enabled = false;
            btnNewSaleMan.Enabled = false;
            txtGetPayment.Enabled = false;
            txtGivePayment.Enabled = false;
            txtAfterDisc.Enabled = false;
            btnPreview.Enabled = false;
            txtSubTotal.Enabled = false;
            txtExtraDisc.Enabled = false;
            
            LoadEmployees();
            LoadItems();
        }





        private void btnOrder_Click(object sender, EventArgs e)
        {
            btnOrder.Enabled = false;
            btnCancel.Enabled = true;
            btnCart.Enabled = true;
            btnRefresh.Enabled = true;
            bxEmployee.Enabled = true;
            txtPrice.Enabled = true;
            txtAmount.Enabled = true;
            txtItems.Enabled = true;
            txtQty.Enabled = true;
            // txtSaleTax.Enabled = true;
            txtTotalPay.Enabled = true;
            btnNewItemAdd.Enabled = true;
            btnNewSaleMan.Enabled = true;
            txtGetPayment.Enabled = true;
            txtGivePayment.Enabled = true;
            txtAfterDisc.Enabled = true;
            txtSubTotal.Enabled = true;
            txtExtraDisc.Enabled = true;
            txtItems.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            bxEmployee.SelectedIndex = -1;
            txtQty.Clear();
            txtPrice.Clear();
            txtTotalPay.Clear();
            txtSaleTax.Clear();
            txtAmount.Clear();
            txtSubTotal.Clear();
            txtGetPayment.Clear();
            txtGivePayment.Clear();
            txtExtraDisc.Clear();
            txtAfterDisc.Clear();
            dataGridViewItems.DataSource = null;
            shopingCart.Clear();
            txtItems.Clear();
            txtTotalPay.Clear();
            btnOrder.Enabled = true;
            btnCancel.Enabled = false;
            btnCart.Enabled = false;
            btnNewSaleMan.Enabled = false;
            btnRefresh.Enabled = false;
            txtPrice.Enabled = false;
            txtAmount.Enabled = false;
            bxEmployee.Enabled = false;
            txtItems.Enabled = false;
            txtQty.Enabled = false;
            txtAfterDisc.Enabled = false;
            txtSaleTax.Enabled = false;
            txtTotalPay.Enabled = false;
            btnNewItemAdd.Enabled = false;
            txtGetPayment.Enabled = false;
            txtGivePayment.Enabled = false;
            txtSubTotal.Enabled = false;
            txtExtraDisc.Enabled = false;
            listBoxSuggestions.DataSource = null;


        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void dataGridViewItems_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                var hti = dataGridViewItems.HitTest(e.X, e.Y);
                dataGridViewItems.Rows[hti.RowIndex].Selected = true;
                contextMenuStrip1.Show(dataGridViewItems, e.X, e.Y);
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int index = dataGridViewItems.CurrentCell.RowIndex;
            shopingCart.RemoveAt(index);

            dataGridViewItems.DataSource = null;
            dataGridViewItems.DataSource = shopingCart;

            CalculateGrossTotal(); // Recalculate the totals after deleting a row

            decimal totalAmount = shopingCart.Sum(x => x.Total_Price);
            txtAmount.Text = totalAmount.ToString();

            decimal disct = 0;
            if (!string.IsNullOrWhiteSpace(txtSaleTax.Text) &&
                decimal.TryParse(txtSaleTax.Text.Trim(), out decimal saleTax))
            {
                disct = saleTax;
            }
            decimal disc = totalAmount - disct;

            txtTotalPay.Text = disc.ToString();
        }

        private void bxItem_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private bool isUpdating = false;

        private void txtSaleTax_TextChanged(object sender, EventArgs e)
        {
            if (isUpdating) return;

            try
            {
                isUpdating = true;
                UpdateTotalPay();
            }
            finally
            {
                isUpdating = false;
            }
        }

        private void txtExtraDisc_TextChanged(object sender, EventArgs e)
        {
            // Ensure txtTotalPay and txtExtraDisc have valid decimal values
            if (decimal.TryParse(txtTotalPay.Text, out decimal totalPay) &&
                decimal.TryParse(txtExtraDisc.Text, out decimal extraDisc))
            {
                // Calculate new subtotal by subtracting extraDisc from totalPay
                decimal subTotal = totalPay - extraDisc;

                // Update txtSubTotal with the new subtotal value
                txtSubTotal.Text = subTotal.ToString("0.00");

                // Optionally update txtGivePayment if needed
                UpdateGivePayment();
            }
            else
            {
                // If parsing fails, ensure txtSubTotal is updated with the original totalPay
                txtSubTotal.Text = txtTotalPay.Text;
            }
            if (string.IsNullOrWhiteSpace(txtExtraDisc.Text) || txtExtraDisc.Text.Trim() == "0")
            {
                txtSubTotal.Clear();
            }
        }

        private void UpdateGivePayment()
        {
            if (decimal.TryParse(txtTotalPay.Text, out decimal totalPay))
            {
                decimal subTotal = 0;
                if (!string.IsNullOrWhiteSpace(txtSubTotal.Text))
                {
                    subTotal = Convert.ToDecimal(txtSubTotal.Text.Trim());
                }

                if (string.IsNullOrWhiteSpace(txtGetPayment.Text) || !decimal.TryParse(txtGetPayment.Text, out decimal cashReceive))
                {
                    txtGivePayment.Text = "0";
                }
                else
                {
                    decimal cashBalance;
                    if (subTotal > 0)
                    {
                        cashBalance = cashReceive - subTotal;
                    }
                    else
                    {
                        cashBalance = cashReceive - totalPay;
                    }
                    txtGivePayment.Text = cashBalance.ToString("0.00");
                }
            }
        }








        private void UpdateTotalPay()
        {
            decimal totalAmount = shopingCart.Sum(x => x.Total_Price);
            txtAmount.Text = totalAmount.ToString();

            // Get the Sale Tax value
            decimal saleTax = 0;
            if (decimal.TryParse(txtSaleTax.Text.Trim(), out saleTax))
            {
                // Calculate Total Pay
                decimal totalPay = totalAmount - saleTax;
                txtTotalPay.Text = totalPay.ToString();
            }
            else
            {
                txtTotalPay.Text = totalAmount.ToString(); // No Sale Tax applied
            }

            // Update SubTotal based on txtTotalPay and txtExtraDisc
            decimal totalPayValue = 0;
            if (decimal.TryParse(txtTotalPay.Text.Trim(), out totalPayValue))
            {
                decimal extraDisc = 0;
                if (decimal.TryParse(txtExtraDisc.Text.Trim(), out extraDisc))
                {
                    // Calculate and update SubTotal
                    txtSubTotal.Text = (totalPayValue - extraDisc).ToString();
                }
                else
                {
                    txtSubTotal.Text = totalPayValue.ToString();
                }
            }
            else
            {
                txtSubTotal.Text = "0";
            }
        }








        private void btnPrint_Click(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.P)
            {
                // Check if dataGridViewItems has any rows
                if (dataGridViewItems.Rows.Count > 0 && bxEmployee.SelectedItem != null)
                {
                    // Validate TotalPay, CashReceive, and SubTotal values before printing
                    if (decimal.TryParse(txtTotalPay.Text, out decimal totalPay) &&
                        decimal.TryParse(txtGetPayment.Text, out decimal cashReceive))
                    {
                        decimal saleTax = 0;
                        decimal subTotal = 0;

                        // If txtSaleTax is not empty, try to parse it
                        if (!string.IsNullOrWhiteSpace(txtSaleTax.Text) &&
                            !decimal.TryParse(txtSaleTax.Text, out saleTax))
                        {
                            MessageBox.Show("Please enter a valid number in Sale Tax.");
                            txtSaleTax.Focus();
                            return;
                        }

                        // If txtSubTotal is not empty, try to parse it
                        if (!string.IsNullOrWhiteSpace(txtSubTotal.Text) &&
                            !decimal.TryParse(txtSubTotal.Text, out subTotal))
                        {
                            MessageBox.Show("Please enter a valid number in Sub Total.");
                            txtSubTotal.Focus();
                            return;
                        }

                        // Validation checks
                        if (saleTax >= totalPay)
                        {
                            MessageBox.Show("Discount Amount must be less than Total Pay.");
                            txtSaleTax.Focus();
                        }
                        /* else if (cashReceive < totalPay)
                          {
                              MessageBox.Show("Cash Receive must be greater than or equal to Total Pay.");
                              txtGetPayment.Focus();
                          }
                          else if (cashReceive < subTotal)
                          {
                              MessageBox.Show("Cash Receive must be greater than or equal to Sub Total.");
                              txtGetPayment.Focus();
                          }
                        */
                        else
                        {
                            CaptureScreenshot();
                            PrintReceipt();
                            txtQty.Clear();
                            txtPrice.Clear();
                            txtTotalPay.Clear();
                            txtSaleTax.Clear();
                            txtAmount.Clear();
                            txtGetPayment.Clear();
                            txtGivePayment.Clear();
                            dataGridViewItems.DataSource = null;
                            shopingCart.Clear();
                            txtItems.Clear();
                            txtExtraDisc.Clear();
                            txtSubTotal.Clear();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter valid numbers in Total Pay and Cash Receive.");
                    }
                }
                else
                {
                    MessageBox.Show("No Data exists to print", "No Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    bxEmployee.Focus();
                }
                e.Handled = true; // Prevent further handling of the key event
            }

            
            if (e.Alt && e.KeyCode == Keys.I)
            {
                txtItems.Focus();
            }
            if (e.Alt && e.KeyCode == Keys.Q)
            {
                txtQty.Focus();
            }
            if (e.Alt && e.KeyCode == Keys.P)
            {
                txtPrice.Focus();
            }
            if (e.Alt && e.KeyCode == Keys.S)
            {
                bxEmployee.Focus();
            }
            if (e.Alt && e.KeyCode == Keys.G)
            {
                txtGetPayment.Focus();
            }
            if (e.Alt && e.KeyCode == Keys.E)
            {
                txtExtraDisc.Focus();
            }
        }

        // Method to capture the screenshot start
        private void CaptureScreenshot()
        {
            try
            {
                // Check if the directory exists, if not create it
                string directoryPath = @"E:\Bills";
                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                // Capture the screen
                Bitmap screenshot = new Bitmap(Screen.PrimaryScreen.Bounds.Width,
                                               Screen.PrimaryScreen.Bounds.Height,
                                               PixelFormat.Format32bppArgb);

                Graphics screenGraph = Graphics.FromImage(screenshot);
                screenGraph.CopyFromScreen(Screen.PrimaryScreen.Bounds.X,
                                           Screen.PrimaryScreen.Bounds.Y,
                                           0, 0,
                                           Screen.PrimaryScreen.Bounds.Size,
                                           CopyPixelOperation.SourceCopy);

                // Save the screenshot to the specified directory
                string filePath = Path.Combine(directoryPath, $"Invoice_screenshot_{DateTime.Now:yyyy-MM-dd_HH-mm-ss tt}.png");
                screenshot.Save(filePath, ImageFormat.Png);

               // MessageBox.Show($"Screenshot captured and saved successfully at {filePath}!", "Screenshot", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to capture screenshot: " + ex.Message);
            }
        }

        // Method to capture the screenshot End


        private void PrintReceipt()
        {
            try
            {
                PrintDocument printDocument1 = new PrintDocument();
                printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);

                // Set printer settings if necessary
                PrintDialog printDialog = new PrintDialog();
                printDialog.Document = printDocument1;
                printDocument1.PrinterSettings = printDialog.PrinterSettings;

                // Print directly without showing a dialog
                printDocument1.Print();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void txtItems_Click(object sender, EventArgs e)
        {
            listBoxSuggestions.Visible = true;
            listBoxSuggestions.BringToFront();
        }

        private void txtItems_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtItems.Text.ToLower();
            var filteredItems = items.Where(item => item.ToLower().Contains(searchText)).ToList();
            listBoxSuggestions.DataSource = filteredItems;
            listBoxSuggestions.Visible = filteredItems.Count > 0;
            listBoxSuggestions.BringToFront();
            // Ensure ListBox has focus
            txtItems.Focus();
        }



        private void txtItems_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (listBoxSuggestions.Visible && listBoxSuggestions.SelectedIndex != -1)
                {
                    txtItems.Text = listBoxSuggestions.SelectedItem.ToString();
                    listBoxSuggestions.Visible = false;
                    txtQty.Focus(); // Move focus to txtQty
                    e.Handled = true;
                }
            }
            else if (e.KeyCode == Keys.Down)
            {
                if (listBoxSuggestions.Visible)
                {
                    // Navigate down in the ListBox
                    if (listBoxSuggestions.Items.Count > 0)
                    {
                        int newIndex = (listBoxSuggestions.SelectedIndex + 1) % listBoxSuggestions.Items.Count;
                        listBoxSuggestions.SelectedIndex = newIndex;
                        listBoxSuggestions.Focus();
                        e.Handled = true;
                    }
                }
            }
            else if (e.KeyCode == Keys.Up)
            {
                if (listBoxSuggestions.Visible)
                {
                    // Navigate up in the ListBox
                    if (listBoxSuggestions.Items.Count > 0)
                    {
                        int newIndex = (listBoxSuggestions.SelectedIndex - 1 + listBoxSuggestions.Items.Count) % listBoxSuggestions.Items.Count;
                        listBoxSuggestions.SelectedIndex = newIndex;
                        listBoxSuggestions.Focus();
                        e.Handled = true;
                    }
                }
            }
        }



        private void listBoxSuggestions_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (listBoxSuggestions.SelectedItem != null)
                {
                    txtItems.Text = listBoxSuggestions.SelectedItem.ToString();
                    listBoxSuggestions.Visible = false;
                    txtQty.Focus(); // Move focus to txtQty
                    e.Handled = true;
                }
            }
            else if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                // Allow the ListBox to handle the Up and Down keys
                e.Handled = false;  // Make sure the ListBox handles these keys
            }
        }



        private void listBoxSuggestions_MouseClick(object sender, MouseEventArgs e)
        {
            if (listBoxSuggestions.SelectedItem != null)
            {
                txtItems.Text = listBoxSuggestions.SelectedItem.ToString();
                listBoxSuggestions.Visible = false;
                txtItems.Focus();
            }
        }

        private void btnNewItemAdd_MouseClick(object sender, MouseEventArgs e)
        {
            LoginToAccess loginToAccess = new LoginToAccess();
            loginToAccess.ShowDialog();
        }


        private void RefreshForm()
        {
            System.Diagnostics.Process.Start(Application.ExecutablePath);

            // Current application ko close karna
            Application.Exit();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshForm();

        }

        private void txtQty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true; // Ignore the key press
            }
            if (e.KeyChar == '.' && txtQty.Text.Contains("."))
            {
                e.Handled = true; // Ignore the key press if there's already a decimal point
            }
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow only numbers, Backspace, and Delete keys
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true; // Ignore the key press
            }
            if (e.KeyChar == '.' && txtPrice.Text.Contains("."))
            {
                e.Handled = true; // Ignore the key press if there's already a decimal point
            }
        }

        private void txtSaleTax_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true; // Ignore the key press
            }
            if (e.KeyChar == '.' && txtSaleTax.Text.Contains("."))
            {
                e.Handled = true; // Ignore the key press if there's already a decimal point
            }
        }

        private void txtQty_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void txtPrice_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void txtQty_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnNewItemAdd_Click(object sender, EventArgs e)
        {

        }

        private void btnNewSaleMan_MouseClick(object sender, MouseEventArgs e)
        {
            LoginToNewSalesman loginToNewSalesman = new LoginToNewSalesman();
            loginToNewSalesman.Show();
        }

        private void btnPreview_Click_1(object sender, EventArgs e)
        {

        }



        private void txtGetPayment_TextChanged(object sender, EventArgs e)
        {
            if (decimal.TryParse(txtTotalPay.Text, out decimal totalPay))
            {
                decimal subTotal = 0;
                if (!string.IsNullOrWhiteSpace(txtSubTotal.Text))
                {
                    subTotal = Convert.ToDecimal(txtSubTotal.Text.Trim());
                }

                if (string.IsNullOrWhiteSpace(txtGetPayment.Text) || !decimal.TryParse(txtGetPayment.Text, out decimal cashReceive))
                {
                    txtGivePayment.Text = "0";
                }
                else
                {
                    decimal cashBalance;
                    if (subTotal > 0)
                    {
                        cashBalance = cashReceive - subTotal;
                    }
                    else
                    {
                        cashBalance = cashReceive - totalPay;
                    }
                    txtGivePayment.Text = cashBalance.ToString();
                }
            }
        }


        private void txtGetPayment_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Check for numeric input and a single decimal point
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true; // Ignore the key press
            }
            if (e.KeyChar == '.' && txtGetPayment.Text.Contains("."))
            {
                e.Handled = true; // Ignore the key press if there's already a decimal point
            }
        }

        private void btnPreview_Click_2(object sender, EventArgs e)
        {

        }


        private void listBoxSuggestions_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txtAfterDisc_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Check for numeric input and a single decimal point
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true; // Ignore the key press
            }
            if (e.KeyChar == '.' && txtAfterDisc.Text.Contains("."))
            {
                e.Handled = true; // Ignore the key press if there's already a decimal point
            }
        }

        private void btnPreview_Click_3(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void backGradiant1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void btnFormClose_MouseClick(object sender, MouseEventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to close the At.Son Software?", "Confirm Exit", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

            // Check the result
            if (result == DialogResult.OK)
            {
                // If No, cancel the form closing
                this.Close();
            }

        }

        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {
            if (isFullscreen)
            {
                // Restore to original windowed mode
                this.FormBorderStyle = originalFormBorderStyle;
                this.Bounds = originalFormBounds;
                this.WindowState = FormWindowState.Normal;
                isFullscreen = false;
            }
            else
            {
                // Save original settings
                originalFormBorderStyle = this.FormBorderStyle;
                originalFormBounds = this.Bounds;

                // Go to fullscreen mode
                this.FormBorderStyle = FormBorderStyle.None;
                this.Bounds = Screen.FromControl(this).Bounds;
                this.WindowState = FormWindowState.Maximized;
                isFullscreen = true;
            }
        }

        private void panel2_MouseClick(object sender, MouseEventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }

        private void backGradiant1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                startPoint = new Point(e.X, e.Y);
            }
        }

        private void backGradiant1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point p = PointToScreen(e.Location);
                this.Location = new Point(p.X - startPoint.X, p.Y - startPoint.Y);
            }
        }

        private void backGradiant1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = false;
            }
        }

        private void backGradiant1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridViewItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTotalPay_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Check for numeric input and a single decimal point
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true; // Ignore the key press
            }
            if (e.KeyChar == '.' && txtQty.Text.Contains("."))
            {
                e.Handled = true; // Ignore the key press if there's already a decimal point
            }
        }

        private void txtExtraDisc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true; // Ignore the key press
            }
            if (e.KeyChar == '.' && txtExtraDisc.Text.Contains("."))
            {
                e.Handled = true; // Ignore the key press if there's already a decimal point
            }
        }
    }

}
