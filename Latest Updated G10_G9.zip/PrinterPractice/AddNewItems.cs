﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PrinterPractice
{
    public partial class AddNewItems : Form
    {
        public string NewItem { get; private set; }
        public AddNewItems()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string newItem = txtNewItemAdd.Text;
            if (!string.IsNullOrEmpty(newItem))
            {
                try
                {
                    // Define the file name
                    string fileName = "items.txt";
                    // Resolve the absolute path relative to the application's executable directory
                    string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);

                    // Debug: Show the file path
                    //MessageBox.Show($"File Path: {filePath}");

                    // Append new item to the file
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine(newItem);
                    }

                    MessageBox.Show("Item Name Added successfully!");
                    txtNewItemAdd.Clear();
                }
                catch (UnauthorizedAccessException ex)
                {
                    MessageBox.Show($"Access Denied: {ex.Message}");
                }
                catch (IOException ex)
                {
                    MessageBox.Show($"IO Error: {ex.Message}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Unexpected Error: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Please enter some text.");
            }
        }


        private void AddNewItems_Load(object sender, EventArgs e)
        {

        }
    }
}
