﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace PrinterPractice
{
    public partial class AddNewSaleManItem : Form
    {
        public AddNewSaleManItem()
        {
            InitializeComponent();
        }

        private void btnAdd_MouseClick(object sender, MouseEventArgs e)
        {
            string newItem = txtNewItemAdd.Text;
            if (!string.IsNullOrEmpty(newItem))
            {
                try
                {
                    // Define the file name
                    string fileName = "NewSaleMan.txt";
                    // Resolve the absolute path relative to the application's executable directory
                    string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);

                    // Debug: Show the file path
                   // MessageBox.Show($"File Path: {filePath}");

                    // Append new item to the file
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine(newItem);
                    }

                    MessageBox.Show("Sales Man Added successfully!");
                    txtNewItemAdd.Clear();
                }
                catch (UnauthorizedAccessException ex)
                {
                    MessageBox.Show($"Access Denied: {ex.Message}");
                }
                catch (IOException ex)
                {
                    MessageBox.Show($"IO Error: {ex.Message}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Unexpected Error: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Please enter some text.");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }
    }
}
