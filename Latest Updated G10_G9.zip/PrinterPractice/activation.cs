﻿using System.Data.SqlClient;
using System.IO.IsolatedStorage;
using System.Windows.Forms;

namespace PrinterPractice
{
    class activation
    {
        const string conn = @"Data Source=FAHAD-AMANAT-KI\SQLEXPRESS;Initial Catalog=ProductKeyDatabase;Integrated Security=True;";
        private static bool Activated { get; set; }

        public static bool isActivated(string key)
        {
            using (SqlConnection sqlconn = new SqlConnection(conn))
            {
                string checkForActivationQuery = "SELECT activated FROM activationTable WHERE serialKey = @key";
                SqlCommand cmd = new SqlCommand(checkForActivationQuery, sqlconn);
                cmd.Parameters.AddWithValue("key", key);
                sqlconn.Open();
                int result = Convert.ToInt32(cmd.ExecuteScalar());
                return result > 0;
            }
        }

        public static void activateSoftware(string key)
        {
            if (!isActivated(key))
            {
                using (SqlConnection sqlConn = new SqlConnection(conn))
                {
                    string checkForKeyQuery = "SELECT COUNT (*) FROM activationTable WHERE serialKey = @key";
                    SqlCommand cmd = new SqlCommand(checkForKeyQuery, sqlConn);
                    cmd.Parameters.AddWithValue("key", key);
                    sqlConn.Open();
                    int result = Convert.ToInt32(cmd.ExecuteScalar());
                    if (result > 0)
                    {
                        updateActivation(key);
                        using (IsolatedStorageFile isolatedStorageFile = IsolatedStorageFile.GetStore(IsolatedStorageScope.User | IsolatedStorageScope.Assembly, null, null))
                        {
                            using (IsolatedStorageFileStream isolatedStorageFileStream = new IsolatedStorageFileStream("setting.txt", System.IO.FileMode.OpenOrCreate, isolatedStorageFile))
                            {
                                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(isolatedStorageFileStream))
                                {
                                    sw.WriteLine(key);
                                }
                            }
                        }
                        Activated = true;
                    }
                    else
                    {
                        MessageBox.Show("Your key was incorrect");
                        Activated = false;
                    }
                }
            }
            else
            {
                MessageBox.Show("Your software is already activated");
                Activated = true;
            }
        }

        public static bool IsActivated => Activated;

        private static void updateActivation(string key)
        {
            using (SqlConnection sqlconn = new SqlConnection(conn))
            {
                string updateQuery = "UPDATE activationTable SET activated = 1 WHERE serialKey = @key";
                SqlCommand cmd = new SqlCommand(updateQuery, sqlconn);
                cmd.Parameters.AddWithValue("@key", key);
                sqlconn.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Your software has been activated");
            }
        }
    }
}
